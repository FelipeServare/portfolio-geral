using System.Drawing;

namespace Street_Fighter_Demo_MOO_ICT
{
    public abstract class Projetil
    {
        // ==============================
        // POSIÇÃO
        // ==============================

        public float WorldX { get; set; }
        public float WorldY { get; set; }


        // ==============================
        // MOVIMENTO
        // ==============================

        public float Speed { get; protected set; }

        public bool Active { get; set; }


        // ==============================
        // ANIMAÇÃO
        // ==============================

        public Image Image { get; protected set; }


        // ==============================
        // CONSTRUTOR
        // ==============================

        protected Projetil(float startX, float startY)
        {
            WorldX = startX;
            WorldY = startY;

            Active = true;
        }


        // ==============================
        // COMPORTAMENTO
        // ==============================

        public abstract void Update(float deltaTime);
    }
}