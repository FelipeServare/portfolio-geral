﻿using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace Street_Fighter_Demo_MOO_ICT
{
public abstract class Personagem
{
// ==============================
// POSIÇÃO
// ==============================

    public float WorldX { get; set; }
    public int WorldY { get; set; }

    public int GroundY { get; protected set; }

    // ==============================
    // MOVIMENTO
    // ==============================

    public float Speed { get; protected set; }

    public bool MovingLeft { get; protected set; }
    public bool MovingRight { get; protected set; }

    public bool Crouching { get; protected set; }
    public bool CrouchedDown { get; protected set; }
    public bool CrouchAttacking { get; protected set; }
    public bool StandingUp { get; protected set; }

    public bool Jumping { get; protected set; }
    public bool FrontJumping { get; protected set; }
    public bool BackJumping { get; protected set; }

    private float jumpVelocity = 0f;
    private float frontJumpVelocityX = 0f;
    private float jumpY = 0f;
    private float backJumpVelocityX = 0f;

    private const float FRONT_JUMP_SPEED = 250f;
    private const float BACK_JUMP_SPEED = 250f;
private const float JUMP_FORCE = 500f;
private const float GRAVITY = 1000f;
private const float ATTACK_GRAVITY = 400f;

    // ==============================
    // TECLAS
    // ==============================

    protected Keys MoveLeftKey { get; set; }
    protected Keys MoveRightKey { get; set; }
    protected Keys CrouchKey { get; set; }
    protected Keys JumpKey { get; set; }

    protected Keys Attack1Key { get; set; }
    protected Keys Attack2Key { get; set; }
    protected Keys Attack3Key { get; set; }

    private bool leftPressed;
    private bool rightPressed;
    private bool upPressed;
    private bool crouchPressed;

    // ==============================
    // PROJÉTIL
    // ==============================

    public int ProjectileOffsetY { get; protected set; }

    // ==============================
    // ANIMAÇÕES
    // ==============================

    public Image CurrentImage { get; protected set; }

    public Image Standing { get; protected set; }
    public Image Backwards { get; protected set; }
    public Image Forwards { get; protected set; }
    public Image Crouched { get; protected set; }

    protected List<Image> StandUpFrames = new();

    protected List<Image> CrouchFrames = new();
    protected List<Image> JumpFrames = new();
    protected List<Image> FrontJumpFrames = new();
    protected List<Image> BackJumpFrames = new();

    protected List<Image> Punch1Frames = new();
    protected List<Image> Punch2Frames = new();

    protected List<Image> CrouchPunch1Frames = new();
    protected List<Image> CrouchPunch2Frames = new();
    protected List<Image> CrouchPunch3Frames = new();

    // ==============================
    // ATAQUES AÉREOS
    // ==============================

    protected List<Image> JumpPunchFrames = new();
    protected List<Image> JumpCotoveladaFrames = new();
    protected List<Image> JumpKickFrames = new();

    protected List<Image> FireballFrames = new();

    public Image FireballAnimation { get; protected set; }

    // ==============================
    // ATAQUES
    // ==============================

    public bool PlayingAction { get; protected set; }

    public int ActionStrength { get; protected set; }

    // ==============================
    // ANIMAÇÃO
    // ==============================

    public int TotalFrame { get; protected set; }
    public int EndFrame { get; protected set; }

    public float AnimationFrame { get; protected set; }

    private int standUpDelay = 0;
    private const int STAND_UP_DELAY = 2;

    // ==============================
    // CONSTRUTOR
    // ==============================

    protected Personagem(float startX, int startY)
    {
        WorldX = startX;
        WorldY = startY;

        GroundY = startY;
        jumpY = startY;
    }

    // ==============================
    // TECLADO - PRESSIONOU
    // ==============================

    public void HandleKeyDown(Keys key)
    {
        // ==============================
        // ESQUERDA
        // ==============================

        if (key == MoveLeftKey && CanWalk())
        {
            leftPressed = true;
        }

        // ==============================
        // DIREITA
        // ==============================

        if (key == MoveRightKey && CanWalk())
        {
            rightPressed = true;
        }

        // ==============================
        // AGACHAR
        // ==============================

        if (key == CrouchKey)
        {
            crouchPressed = true;

            if (!Crouching &&
                !CrouchedDown &&
                !PlayingAction &&
                !MovingLeft &&
                !MovingRight &&
                !Jumping &&
                !FrontJumping)
            {
                BeginCrouch();
            }
        }

        // ==============================
        // UP PRESSIONADO
        // ==============================

        if (key == JumpKey)
        {
            upPressed = true;
        }
        if (upPressed &&
    leftPressed &&
    !Jumping &&
    !FrontJumping &&
    !BackJumping &&
    !Crouching &&
    !CrouchedDown &&
    !StandingUp &&
    !PlayingAction
    )
{
    BackJumping = true;

    jumpY = WorldY;
    jumpVelocity = -JUMP_FORCE;

    // Movimento para trás
    backJumpVelocityX = -BACK_JUMP_SPEED;

    MovingLeft = false;
    MovingRight = false;

    StopGifAnimations();

    AnimationFrame = 0;

    StartFrameAnimation(BackJumpFrames);

    return;
}
        // ==============================
        // FRONT JUMP
        // UP + RIGHT
        // ==============================

if (upPressed &&
    rightPressed &&
    !Jumping &&
    !FrontJumping &&
    !Crouching &&
    !CrouchedDown &&
    !StandingUp &&
    !PlayingAction &&
    !BackJumping)
{
    FrontJumping = true;

    jumpY = WorldY;
    jumpVelocity = -JUMP_FORCE;
    frontJumpVelocityX = FRONT_JUMP_SPEED;

    // O movimento horizontal agora é controlado
    // pelo próprio FrontJump.
    MovingLeft = false;
    MovingRight = false;

    StopGifAnimations();

    AnimationFrame = 0;

    StartFrameAnimation(FrontJumpFrames);

    return;
}

        // ==============================
        // PULO NORMAL
        // ==============================

        if (key == JumpKey &&
            !Jumping &&
            !FrontJumping &&
            !Crouching &&
            !CrouchedDown &&
            !StandingUp &&
            !PlayingAction &&
            !BackJumping)
        {
            Jumping = true;

            jumpY = WorldY;
            jumpVelocity = -JUMP_FORCE;

            StopGifAnimations();

            AnimationFrame = 0;

            StartFrameAnimation(JumpFrames);
        }
    }

    // ==============================
    // TECLADO - SOLTOU
    // ==============================

    public void HandleKeyUp(Keys key)
    {
        if (key == MoveLeftKey)
            leftPressed = false;

        if (key == MoveRightKey)
            rightPressed = false;

        if (key == JumpKey)
            upPressed = false;

        // ==============================
        // SOLTOU O AGACHAMENTO
        // ==============================

        if (key == CrouchKey)
        {
            crouchPressed = false;

            if (CrouchedDown &&
                !StandingUp &&
                !PlayingAction)
            {
                BeginStandUp();
            }
        }

        // ==============================
        // ATAQUES
        // ==============================

        if (key == Attack1Key && CanAttack())
            Attack(1);

        if (key == Attack2Key && CanAttack())
            Attack(2);

        if (key == Attack3Key && CanAttack())
            Attack(3);
    }

    // ==============================
    // VERIFICA SE PODE ATACAR
    // ==============================

private bool CanAttack()
{
    if (PlayingAction)
        return false;

    if (Crouching || StandingUp)
        return false;

    if (Jumping ||
        FrontJumping ||
        BackJumping)
    {
        return true;
    }

    return !MovingLeft && !MovingRight;
}

    // ==============================
    // VERIFICA SE PODE ANDAR
    // ==============================

    private bool CanWalk()
    {
        if (PlayingAction)
            return false;

        return true;
    }

    // ==============================
    // MOVIMENTO
    // ==============================

public void UpdateMovement(float deltaTime)
{
    // ==============================
// BACK JUMP
// ==============================

if (BackJumping)
{
    float gravity = GRAVITY;

    // Durante o ataque aéreo,
    // a queda fica mais lenta.
    if (PlayingAction &&
        (ActionStrength == 50 ||
         ActionStrength == 60 ||
         ActionStrength == 70))
    {
        gravity = ATTACK_GRAVITY;
    }

    jumpVelocity += gravity * deltaTime;
    jumpY += jumpVelocity * deltaTime;

    WorldY = (int)jumpY;

    // Movimento para trás
    WorldX += backJumpVelocityX * deltaTime;

    if (jumpY >= GroundY)
    {
        jumpY = GroundY;
        WorldY = GroundY;

        BackJumping = false;

        jumpVelocity = 0f;
        backJumpVelocityX = 0f;

        MovingLeft = false;
        MovingRight = false;

        PlayingAction = false;
        ActionStrength = 0;

        CurrentImage = Standing;
        SetUpAnimation();
    }

    return;
}
    // ==============================
    // FRONT JUMP
    // ==============================

    if (FrontJumping)
    {
        float gravity = GRAVITY;

        // Durante o ataque aéreo,
        // a queda fica mais lenta.
        if (PlayingAction &&
            (ActionStrength == 50 ||
             ActionStrength == 60 ||
             ActionStrength == 70))
        {
            gravity = ATTACK_GRAVITY;
        }

        jumpVelocity += gravity * deltaTime;
        jumpY += jumpVelocity * deltaTime;

        WorldY = (int)jumpY;

        // Continua avançando durante o front jump
        WorldX += frontJumpVelocityX * deltaTime;

        // Chegou ao chão
        if (jumpY >= GroundY)
        {
            jumpY = GroundY;
            WorldY = GroundY;

            FrontJumping = false;
            jumpVelocity = 0f;
            frontJumpVelocityX = 0f;

            MovingLeft = false;
            MovingRight = false;

            PlayingAction = false;
            ActionStrength = 0;

            CurrentImage = Standing;
            SetUpAnimation();
        }

        return;
    }

    // ==============================
    // NORMAL JUMP
    // ==============================

    if (Jumping)
    {
        float gravity = GRAVITY;

        // Durante o ataque aéreo,
        // a queda fica mais lenta.
        if (PlayingAction &&
            (ActionStrength == 50 ||
             ActionStrength == 60 ||
             ActionStrength == 70))
        {
            gravity = ATTACK_GRAVITY;
        }

        jumpVelocity += gravity * deltaTime;
        jumpY += jumpVelocity * deltaTime;

        WorldY = (int)jumpY;

        // Chegou ao chão
        if (jumpY >= GroundY)
        {
            jumpY = GroundY;
            WorldY = GroundY;

            Jumping = false;
            jumpVelocity = 0f;

            MovingLeft = false;
            MovingRight = false;

            PlayingAction = false;
            ActionStrength = 0;

            CurrentImage = Standing;
            SetUpAnimation();
        }

        return;
    }

    // ==============================
    // CROUCH
    // ==============================

    if (Crouching ||
        CrouchedDown ||
        StandingUp)
    {
        return;
    }

    // ==============================
    // MOVIMENTO NORMAL
    // ==============================

    if (leftPressed && !rightPressed)
    {
        if (!MovingLeft)
            MoveLeft();

        MovingLeft = true;
        MovingRight = false;

        WorldX -= Speed * deltaTime;
    }
    else if (rightPressed && !leftPressed)
    {
        if (!MovingRight)
            MoveRight();

        MovingRight = true;
        MovingLeft = false;

        WorldX += Speed * deltaTime;
    }
    else
    {
        if (PlayingAction)
        {
            MovingLeft = false;
            MovingRight = false;
            return;
        }

        if (MovingLeft || MovingRight)
        {
            MovingLeft = false;
            MovingRight = false;

            Reset();
        }
    }
}

    // ==============================
    // LIMITES
    // ==============================

    public void LimitPosition(float worldWidth)
    {
        if (WorldX < 0)
        {
            WorldX = 0;
        }

        if (WorldX + CurrentImage.Width > worldWidth)
        {
            WorldX = worldWidth - CurrentImage.Width;
        }
    }

    // ==============================
    // CONFIGURA ANIMAÇÃO
    // ==============================

    protected void SetUpAnimation()
    {
        ImageAnimator.StopAnimate(
            CurrentImage,
            null
        );

        ImageAnimator.Animate(
            CurrentImage,
            null
        );

        FrameDimension dimensions =
            new FrameDimension(
                CurrentImage.FrameDimensionsList[0]
            );

        TotalFrame =
            CurrentImage.GetFrameCount(
                dimensions
            );

        EndFrame =
            TotalFrame - 3;

        AnimationFrame = 0;
    }

    // ==============================
    // ATUALIZA ANIMAÇÃO
    // ==============================

public void UpdateAnimation(float deltaTime)
{
    // ==============================
    // CROUCHING
    // ==============================

    if (Crouching)
    {
        AnimationFrame += 0.5f;

        UpdateFrameAnimation(CrouchFrames);

        if (AnimationFrame >= TotalFrame)
        {
            Crouching = false;

            if (crouchPressed)
            {
                CrouchedDown = true;
                ChangeAnimation(Crouched);
                return;
            }

            BeginStandUp();
            return;
        }

        return;
    }


    // ==============================
    // STANDING UP
    // ==============================

    if (StandingUp)
    {
        UpdateFrameAnimation(StandUpFrames);

        standUpDelay++;

        if (standUpDelay >= STAND_UP_DELAY)
        {
            StandingUp = false;
            CrouchedDown = false;
            standUpDelay = 0;

            ChangeAnimation(Standing);
            return;
        }

        return;
    }


    // ==============================
    // ATTACK
    // ==============================

    if (PlayingAction)
    {
        AnimationFrame += 0.5f;

        // ------------------------------
        // ATAQUES AÉREOS
        // ------------------------------

        if (ActionStrength == 50)
        {
            UpdateFrameAnimation(JumpPunchFrames);
        }
        else if (ActionStrength == 60)
        {
            UpdateFrameAnimation(JumpCotoveladaFrames);
        }
        else if (ActionStrength == 70)
        {
            UpdateFrameAnimation(JumpKickFrames);
        }

        // ------------------------------
        // ATAQUES NORMAIS
        // ------------------------------

        else if (ActionStrength == 5)
        {
            UpdateFrameAnimation(Punch1Frames);
        }
        else if (ActionStrength == 10)
        {
            UpdateFrameAnimation(Punch2Frames);
        }
        else if (ActionStrength == 30)
        {
            UpdateFrameAnimation(FireballFrames);
        }

        // ------------------------------
        // ATAQUES AGACHADOS
        // ------------------------------

        else if (ActionStrength == 35)
        {
            UpdateFrameAnimation(CrouchPunch1Frames);
        }
        else if (ActionStrength == 40)
        {
            UpdateFrameAnimation(CrouchPunch2Frames);
        }
        else if (ActionStrength == 45)
        {
            UpdateFrameAnimation(CrouchPunch3Frames);
        }


        // ==============================
        // FIM DA ANIMAÇÃO DE ATAQUE
        // ==============================

        if (AnimationFrame >= TotalFrame)
        {
            // ------------------------------
            // ATAQUE AÉREO
            // ------------------------------

            if (ActionStrength == 50 ||
                ActionStrength == 60 ||
                ActionStrength == 70)
            {
                PlayingAction = false;
                ActionStrength = 0;
                // ==============================
                // BACK JUMP
                // ==============================

if (BackJumping)
{
    AnimationFrame += 0.5f;

    UpdateFrameAnimation(BackJumpFrames);

    return;
}
                // ==========================
                // FRONT JUMP
                // ==========================

                if (FrontJumping)
                {
                    if (FrontJumpFrames.Count > 0)
                    {
                        AnimationFrame = 0;
                        TotalFrame = FrontJumpFrames.Count;
                        EndFrame = FrontJumpFrames.Count - 1;

                        CurrentImage = FrontJumpFrames[0];
                    }

                    return;
                }


                // ==========================
                // PULO NORMAL
                // ==========================

                if (Jumping)
                {
                    if (JumpFrames.Count > 0)
                    {
                        AnimationFrame = 0;
                        TotalFrame = JumpFrames.Count;
                        EndFrame = JumpFrames.Count - 1;

                        CurrentImage = JumpFrames[0];
                    }

                    return;
                }

                return;
            }


            // ==============================
            // ATAQUE AGACHADO
            // ==============================

            if (CrouchedDown)
            {
                PlayingAction = false;
                ActionStrength = 0;

                if (crouchPressed)
                {
                    ChangeAnimation(Crouched);
                }
                else
                {
                    BeginStandUp();
                }

                return;
            }


            // ==============================
            // ATAQUE NORMAL
            // ==============================

            Reset();

            return;
        }

        return;
    }


    // ==============================
    // FRONT JUMP
    // ==============================

    if (FrontJumping)
    {
        AnimationFrame += 0.5f;

        UpdateFrameAnimation(FrontJumpFrames);

        return;
    }


    // ==============================
    // NORMAL JUMP
    // ==============================

    if (Jumping)
    {
        AnimationFrame += 0.5f;

        UpdateFrameAnimation(JumpFrames);

        return;
    }
}

    // ==============================
    // COMEÇA A AGACHAR
    // ==============================

    protected void BeginCrouch()
    {
        Crouching = true;
        CrouchedDown = false;
        StandingUp = false;

        MovingLeft = false;
        MovingRight = false;

        StartFrameAnimation(CrouchFrames);
    }

    // ==============================
    // COMEÇA A LEVANTAR
    // ==============================

    protected void BeginStandUp()
    {
        Crouching = false;
        CrouchedDown = false;
        StandingUp = true;

        MovingLeft = false;
        MovingRight = false;

        standUpDelay = 0;

        StartFrameAnimation(StandUpFrames);
    }

    // ==============================
    // TROCA ANIMAÇÃO
    // ==============================

    protected void ChangeAnimation(Image animation)
    {
        if (CurrentImage == animation)
            return;

        ImageAnimator.StopAnimate(
            CurrentImage,
            null
        );

        CurrentImage = animation;

        AnimationFrame = 0;

        FrameDimension dimensions =
            new FrameDimension(
                CurrentImage.FrameDimensionsList[0]
            );

        TotalFrame =
            CurrentImage.GetFrameCount(
                dimensions
            );

        EndFrame =
            TotalFrame - 3;

        ImageAnimator.Animate(
            CurrentImage,
            null
        );
    }

    // ==============================
    // PARA GIFS
    // ==============================

    protected void StopGifAnimations()
    {
        ImageAnimator.StopAnimate(
            Standing,
            null
        );

        ImageAnimator.StopAnimate(
            Backwards,
            null
        );

        ImageAnimator.StopAnimate(
            Forwards,
            null
        );

        ImageAnimator.StopAnimate(
            Crouched,
            null
        );
    }

    // ==============================
    // INICIA ANIMAÇÃO PNG
    // ==============================

    protected void StartFrameAnimation(List<Image> frames)
    {
        if (frames.Count == 0)
            return;

        StopGifAnimations();

        AnimationFrame = 0;

        TotalFrame = frames.Count;

        EndFrame = frames.Count - 1;

        CurrentImage = frames[0];
    }

    // ==============================
    // ATUALIZA FRAME PNG
    // ==============================

    protected void UpdateFrameAnimation(List<Image> frames)
    {
        if (frames.Count == 0)
            return;

        int frame = (int)AnimationFrame;

        if (frame >= frames.Count)
            frame = frames.Count - 1;

        CurrentImage = frames[frame];
    }

    // ==============================
    // CARREGA GIF
    // ==============================

    protected List<Image> GetGifFrames(string path)
    {
        List<Image> frames = new();

        using Image gif = Image.FromFile(path);

        FrameDimension dimension =
            new FrameDimension(
                gif.FrameDimensionsList[0]
            );

        int frameCount =
            gif.GetFrameCount(dimension);

        string gifName =
            Path.GetFileNameWithoutExtension(path);

        string debugPath =
            Path.Combine(
                AppContext.BaseDirectory,
                "debug_frames",
                gifName
            );

        Directory.CreateDirectory(debugPath);

        File.AppendAllText(
            Path.Combine(
                AppContext.BaseDirectory,
                "debug_log.txt"
            ),
            $"GIF: {path}\n" +
            $"DEBUG PATH: {debugPath}\n\n"
        );

        for (int i = 0; i < frameCount; i++)
        {
            gif.SelectActiveFrame(
                dimension,
                i
            );

            Bitmap frame = new Bitmap(
                gif.Width,
                gif.Height
            );

            using Graphics graphics =
                Graphics.FromImage(frame);

            graphics.Clear(
                Color.Transparent
            );

            graphics.DrawImage(
                gif,
                0,
                0,
                gif.Width,
                gif.Height
            );

            frame.Save(
                Path.Combine(
                    debugPath,
                    $"frame_{i:D2}.png"
                ),
                ImageFormat.Png
            );

            frames.Add(frame);
        }

        return frames;
    }

    // ==============================
    // CARREGA PNG
    // ==============================

    protected List<Image> GetPngFrames(string folder)
    {
        List<Image> frames = new();

        string[] files =
            Directory.GetFiles(
                folder,
                "*.png"
            );

        Array.Sort(files);

        // ==============================
        // DESCOBRIR MAIOR TAMANHO
        // ==============================

        int canvasWidth = 0;
        int canvasHeight = 0;

        foreach (string file in files)
        {
            using Image original =
                Image.FromFile(file);

            if (original.Width > canvasWidth)
                canvasWidth = original.Width;

            if (original.Height > canvasHeight)
                canvasHeight = original.Height;
        }

        Console.WriteLine(
            $"Canvas da animação: " +
            $"{canvasWidth}x{canvasHeight}"
        );

        // ==============================
        // CRIAR FRAMES
        // ==============================

        foreach (string file in files)
        {
            using Image original =
                Image.FromFile(file);

            Bitmap frame =
                new Bitmap(
                    canvasWidth,
                    canvasHeight
                );

            using (
                Graphics graphics =
                Graphics.FromImage(frame)
            )
            {
                graphics.Clear(
                    Color.Transparent
                );

                // ==============================
                // CENTRALIZA HORIZONTALMENTE
                // ==============================

                int x =
                    (canvasWidth -
                     original.Width) / 2;

                // ==============================
                // ALINHA PELA BASE
                // ==============================

                int y =
                    canvasHeight -
                    original.Height;

                graphics.DrawImage(
                    original,
                    x,
                    y,
                    original.Width,
                    original.Height
                );
            }

            Console.WriteLine(
                $"{Path.GetFileName(file)} -> " +
                $"{original.Width}x" +
                $"{original.Height} " +
                $"=> canvas " +
                $"{canvasWidth}x" +
                $"{canvasHeight}"
            );

            frames.Add(frame);
        }

        return frames;
    }

    // ==============================
    // COMPORTAMENTOS
    // ==============================

    public abstract void MoveLeft();

    public abstract void MoveRight();

    public abstract void Attack(int attack);

    public abstract void Reset();
}


}
