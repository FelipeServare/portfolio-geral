using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Diagnostics;

namespace Street_Fighter_Demo_MOO_ICT
{
    public partial class Form1 : Form
    {
        // ==============================
        // JOGO
        // ==============================

        private const int GAME_WIDTH = 800;
        private const int GAME_HEIGHT = 450;

        private Bitmap gameBuffer;

        private Image background;
        private Image drum;
        private Image drumNormal;
        private Image drumHit;

        // ==============================
        // POSIÇÕES
        // ==============================

        private int playerX = 0;

        private int drumX = 450;
        private const int drumY = 355;

        private float cameraX = 0f;
        private float drumWorldX = 450f;

        
        // ==============================
        // BARRIL
        // ==============================

        private int drumMoveTime = 0;

        // ==============================
        // TEMPO
        // ==============================

        private float deltaTime;
        private long lastTime;

        private readonly Stopwatch gameClock = new Stopwatch();

        // ==============================
        // PERSONAGENS
        // ==============================

        private Personagem jogador1;
        private Personagem jogador2;

        
        // ==============================
        // BACKGROUNDS
        // ==============================

        private List<string> background_images = new List<string>();
        private int bg_number = 0;


        // ==============================
        // CONSTRUTOR
        // ==============================

        public Form1()
        {
            InitializeComponent();
            SetUpForm();
        }


        // ==============================
        // TECLADO
        // ==============================

        private void KeyIsDown(object sender, KeyEventArgs e)
        {
            jogador1.HandleKeyDown(e.KeyCode);
        }


        private void KeyIsUp(object sender, KeyEventArgs e)
        {
            // Trocar cenário
            if (e.KeyCode == Keys.X)
            {
                ChangeBackground();
            }

            jogador1.HandleKeyUp(e.KeyCode);

        }


        // ==============================
        // TROCAR BACKGROUND
        // ==============================

        private void ChangeBackground()
        {
            if (bg_number < background_images.Count - 1)
            {
                bg_number++;
            }
            else
            {
                bg_number = 0;
            }

            background = Image.FromFile(
                background_images[bg_number]
            );

            cameraX = 0;

            drumMoveTime = 0;

            drumWorldX = 450;
            drumX = 450;

            jogador1.WorldX = 0;
            playerX = 0;
        }


        // ==============================
        // DESENHAR JOGO
        // ==============================

        private void FormPaintEvent(object sender, PaintEventArgs e)
        {
            using (Graphics g = Graphics.FromImage(gameBuffer))
            {
                g.Clear(Color.Black);

                // Background
                g.DrawImage(
                    background,
                    new Point(-(int)cameraX, 0)
                );

// ==============================
// JOGADOR
// ==============================
int frameWidth = jogador1.CurrentImage.Width;
int frameHeight = jogador1.CurrentImage.Height;

// Mantém o lado esquerdo do personagem fixo
int characterX = playerX;

// Mantém os pés alinhados
int characterY =
    jogador1.WorldY +
    jogador1.Standing.Height -
    frameHeight;

g.DrawImage(
    jogador1.CurrentImage,
    new Rectangle(
        characterX,
        characterY,
        frameWidth,
        frameHeight
    )
);
                // Barril
                g.DrawImage(
                    drum,
                    new Point(
                        drumX,
                        drumY
                    )
                );

                // Projetil
                if (jogador1 is IProjetil personagemProjetil &&
                    personagemProjetil.Projectile != null &&
                    personagemProjetil.Projectile.Active)
                {
                    int projectileX =
                        (int)(
                            personagemProjetil.Projectile.WorldX
                            - cameraX
                        );

                    int projectileY =
                        (int)personagemProjetil.Projectile.WorldY;

                    g.DrawImage(
                        personagemProjetil.Projectile.Image,
                        new Point(
                            projectileX,
                            projectileY
                        )
                    );
                }
            }

            // ==============================
            // ESCALA DA TELA
            // ==============================

            float scaleX =
                (float)ClientSize.Width / GAME_WIDTH;

            float scaleY =
                (float)ClientSize.Height / GAME_HEIGHT;

            float scale =
                Math.Min(scaleX, scaleY);

            int renderWidth =
                (int)(GAME_WIDTH * scale);

            int renderHeight =
                (int)(GAME_HEIGHT * scale);

            int renderX =
                (ClientSize.Width - renderWidth) / 2;

            int renderY =
                (ClientSize.Height - renderHeight) / 2;

            e.Graphics.Clear(Color.Black);

            e.Graphics.InterpolationMode =
                InterpolationMode.NearestNeighbor;

            e.Graphics.PixelOffsetMode =
                PixelOffsetMode.Half;

            e.Graphics.DrawImage(
                gameBuffer,
                new Rectangle(
                    renderX,
                    renderY,
                    renderWidth,
                    renderHeight
                )
            );
        }


        // ==============================
        // LOOP DO JOGO
        // ==============================

private void GameTimerEvent(object sender, EventArgs e)
{
    UpdateDeltaTime();

    jogador1.UpdateMovement(deltaTime);

    jogador1.UpdateAnimation(deltaTime);

    jogador1.LimitPosition(
        background.Width
    );

    ImageAnimator.UpdateFrames();

    UpdateCamera();

    CheckPunchHit();
    UpdateProjectile();
    UpdateDrum();

    Invalidate();
}


        // ==============================
        // DELTA TIME
        // ==============================

        private void UpdateDeltaTime()
        {
            long currentTime =
                gameClock.ElapsedMilliseconds;

            deltaTime =
                (currentTime - lastTime) / 1000f;

            lastTime = currentTime;
        }


        // ==============================
        // CÂMERA
        // ==============================

        private void UpdateCamera()
        {
playerX =
    (int)(
        jogador1.WorldX
        - cameraX
    );

            // Jogador chegou perto da direita
            if (playerX > 600)
            {
                cameraX =
                    jogador1.WorldX - 600;
            }

            // Jogador chegou perto da esquerda
            if (playerX < 200)
            {
                cameraX =
                    jogador1.WorldX - 200;
            }

            // Limite esquerdo
            if (cameraX < 0)
            {
                cameraX = 0;
            }

            // Limite direito
            float maxCameraX =
                background.Width - GAME_WIDTH;

            if (maxCameraX < 0)
            {
                maxCameraX = 0;
            }

            if (cameraX > maxCameraX)
            {
                cameraX = maxCameraX;
            }

            // Posições na tela
            playerX =
                (int)(
                    jogador1.WorldX
                    - cameraX
                );

            drumX =
                (int)(
                    drumWorldX
                    - cameraX
                );
        }


        // ==============================
        // PROJÉTIL
        // ==============================

        private void UpdateProjectile()
        {
            if (jogador1 is not IProjetil personagemProjetil)
            {
                return;
            }

            if (personagemProjetil.Projectile != null)
            {
                personagemProjetil.Projectile.Update(deltaTime);

                CheckProjectileHit();

                if (personagemProjetil.Projectile != null &&
                    personagemProjetil.Projectile.WorldX > background.Width)
                {
                    personagemProjetil.RemoveProjectile();
                }

                return;
            }

            if (personagemProjetil.ShouldShootFireball())
            {
                personagemProjetil.ShootProjectile();
            }
        }


        // ==============================
        // ATAQUE FÍSICO
        // ==============================

        private void CheckPunchHit()
        {
            int jogadorX =
                (int)(
                    jogador1.WorldX
                    - cameraX
                );

            bool collision =
                DetectCollision(
                    jogadorX,
                    jogador1.WorldY,
                    jogador1.CurrentImage.Width,
                    jogador1.CurrentImage.Height,

                    drumX,
                    drumY,
                    drum.Width,
                    drum.Height
                );

            if (collision &&
                jogador1.PlayingAction &&
                jogador1.AnimationFrame >
                jogador1.EndFrame)
            {
                drumMoveTime =
                    jogador1.ActionStrength;
            }
        }


        // ==============================
        // COLISÃO DO PROJÉTIL
        // ==============================

        private void CheckProjectileHit()
        {
            if (jogador1 is not IProjetil personagemProjetil)
            {
                return;
            }

            if (personagemProjetil.Projectile == null)
            {
                return;
            }

            Projetil projetil =
                personagemProjetil.Projectile;

            int projectileX =
                (int)(
                    projetil.WorldX
                    - cameraX
                );

            int projectileY =
                (int)projetil.WorldY;

            bool collision =
                DetectCollision(
                    projectileX,
                    projectileY,
                    projetil.Image.Width,
                    projetil.Image.Height,

                    drumX,
                    drumY,
                    drum.Width,
                    drum.Height
                );

            if (collision)
            {
                drumMoveTime = 30;

                projetil.Active = false;

                personagemProjetil.RemoveProjectile();
            }
        }


        // ==============================
        // BARRIL
        // ==============================

        private void UpdateDrum()
        {
            if (drumMoveTime > 0)
            {
                drumMoveTime--;

                drumWorldX +=
                    500f * deltaTime;

                drum = drumHit;
            }
            else
            {
                drum = drumNormal;

                drumMoveTime = 0;
            }

            // Reinicia o barril
            if (drumWorldX >= GAME_WIDTH)
            {
                drumMoveTime = 0;

                drumWorldX = 450;

                drum = drumNormal;
            }
        }


        // ==============================
        // CONFIGURAÇÃO
        // ==============================

        private void SetUpForm()
        {
            SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.UserPaint,
                true
            );

            // Buffer
            gameBuffer =
                new Bitmap(
                    GAME_WIDTH,
                    GAME_HEIGHT
                );

            // Caminho base
            string basePath =
                AppContext.BaseDirectory;

            // Jogador
            jogador1 =
                new Ryu(0, 320);

            // Background
            string backgroundPath =
                Path.Combine(
                    basePath,
                    "background"
                );

            background_images =
                Directory
                    .GetFiles(
                        backgroundPath,
                        "*.jpg"
                    )
                    .ToList();

            background =
                Image.FromFile(
                    background_images[bg_number]
                );

            // Barril
            drumNormal =
                Image.FromFile(
                    Path.Combine(
                        basePath,
                        "drum.png"
                    )
                );

            drumHit =
                Image.FromFile(
                    Path.Combine(
                        basePath,
                        "hitdrum.png"
                    )
                );

            drum = drumNormal;

            // Relógio
            gameClock.Start();

            lastTime =
                gameClock.ElapsedMilliseconds;
        }


        // ==============================
        // COLISÃO
        // ==============================

        private bool DetectCollision(
            int object1X,
            int object1Y,
            int object1Width,
            int object1Height,

            int object2X,
            int object2Y,
            int object2Width,
            int object2Height)
        {
            return !(
                object1X + object1Width <= object2X ||
                object1X >= object2X + object2Width ||
                object1Y + object1Height <= object2Y ||
                object1Y >= object2Y + object2Height
            );
        }
    }
}