namespace Street_Fighter_Demo_MOO_ICT
{
    public interface IProjetil
    {
        Projetil? Projectile { get; }

        void ShootProjectile();

        void RemoveProjectile();

        bool ShouldShootFireball();
    }
}