using System.Drawing;

namespace Street_Fighter_Demo_MOO_ICT
{
    public class Fireball : Projetil
    {
        public Fireball(float startX, float startY)
            : base(startX, startY)
        {
            string basePath = AppContext.BaseDirectory;

            Image = Image.FromFile(
                Path.Combine(basePath, "FireBallFinal.gif")
            );

            Speed = 500f;

            ImageAnimator.Animate(Image, null);
        }


        public override void Update(float deltaTime)
        {
            WorldX += Speed * deltaTime;
        }
    }
}