using System.Drawing;
using System.Windows.Forms;

namespace Street_Fighter_Demo_MOO_ICT
{
    public class Ryu : Personagem, IProjetil
    {
        public Projetil? Projectile { get; private set; }

        public bool projectileFired = false;

        public Ryu(float startX, int startY)
            : base(startX, startY)
        {
            string basePath = AppContext.BaseDirectory;

            // ==============================
            // ANIMAÇÕES
            // ==============================

            Standing = Image.FromFile(
                Path.Combine(basePath, "standing.gif")
            );

            Backwards = Image.FromFile(
                Path.Combine(basePath, "backwards.gif")
            );

            Forwards = Image.FromFile(
                Path.Combine(basePath, "forwards.gif")
            );

            Crouched = Image.FromFile(
                Path.Combine(basePath, "crouching_right2.gif")
            );

            CrouchFrames = GetGifFrames(
                Path.Combine(basePath, "crouching_right.gif")
            );
StandUpFrames = GetGifFrames(
    Path.Combine(basePath, "standUp_right.gif")
);

JumpFrames = GetPngFrames(
    Path.Combine(basePath, "jump_frames")
);

FrontJumpFrames = GetPngFrames(
    Path.Combine(basePath, "front_jump_frames")
);
BackJumpFrames = GetPngFrames(
    Path.Combine(basePath, "jump_frames")
);
Punch1Frames = GetGifFrames(
    Path.Combine(basePath, "punch1.gif")
);

Punch2Frames = GetGifFrames(
    Path.Combine(basePath, "punch2.gif")
);
CrouchPunch1Frames = GetPngFrames(
    Path.Combine(basePath, "crouch_punch_frames")
);

CrouchPunch2Frames = GetPngFrames(
    Path.Combine(basePath, "crouch_kick_frames")
);

CrouchPunch3Frames = GetPngFrames(
    Path.Combine(basePath, "upercut_frames")
);

JumpPunchFrames = GetPngFrames(
    Path.Combine(basePath, "jump_punch_frames")
);

JumpCotoveladaFrames = GetPngFrames(
    Path.Combine(basePath, "jump_cotovelada_frames")
);

JumpKickFrames = GetPngFrames(
    Path.Combine(basePath, "jump_kick_frames")
);

FireballFrames = GetGifFrames(
    Path.Combine(basePath, "fireball.gif")
);



            // ==============================
            // ESTADO INICIAL
            // ==============================

            CurrentImage = Standing;

            Speed = 200f;

            ProjectileOffsetY = 33;

            // ==============================
            // CONTROLES DO RYU
            // ==============================

            MoveLeftKey = Keys.Left;
            MoveRightKey = Keys.Right;
            CrouchKey = Keys.Down;
            JumpKey = Keys.Up;

            Attack1Key = Keys.A;
            Attack2Key = Keys.S;
            Attack3Key = Keys.D;
        }


        // ==============================
        // MOVIMENTO
        // ==============================

        public override void MoveLeft()
        {
            CurrentImage = Backwards;
            SetUpAnimation();
        }

        public override void MoveRight()
        {
            CurrentImage = Forwards;
            SetUpAnimation();
        }


        // ==============================
        // ATAQUES
        // ==============================


public override void Attack(int attack)
{
    // ==============================
    // ATAQUES AÉREOS
    // ==============================

    if (Jumping || FrontJumping || BackJumping)
    {
        if (attack == 1)
        {
            PlayingAction = true;
            ActionStrength = 50;

            StartFrameAnimation(JumpPunchFrames);
        }
        else if (attack == 2)
        {
            PlayingAction = true;
            ActionStrength = 60;

            StartFrameAnimation(JumpCotoveladaFrames);
        }
        else if (attack == 3)
        {
            PlayingAction = true;
            ActionStrength = 70;

            StartFrameAnimation(JumpKickFrames);
        }

        return;
    }


    // ==============================
    // ATAQUES AGACHADOS
    // ==============================

    if (CrouchedDown)
    {
        PlayingAction = true;

        if (attack == 1)
        {
            ActionStrength = 35;
            StartFrameAnimation(CrouchPunch1Frames);
        }
        else if (attack == 2)
        {
            ActionStrength = 40;
            StartFrameAnimation(CrouchPunch2Frames);
        }
        else if (attack == 3)
        {
            ActionStrength = 45;
            StartFrameAnimation(CrouchPunch3Frames);
        }

        return;
    }


    // ==============================
    // ATAQUES NORMAIS
    // ==============================

    PlayingAction = true;

    if (attack == 1)
    {
        ActionStrength = 5;
        StartFrameAnimation(Punch1Frames);
    }
    else if (attack == 2)
    {
        ActionStrength = 10;
        StartFrameAnimation(Punch2Frames);
    }
    else if (attack == 3)
    {
        ActionStrength = 30;
        StartFrameAnimation(FireballFrames);
    }
}



        // ==============================
        // PROJÉTIL
        // ==============================

        public void ShootProjectile()
        {
            if (Projectile != null)
                return;

            Projectile = new Fireball(
                WorldX + CurrentImage.Width - 50,
                WorldY - ProjectileOffsetY
            );
        }

        public void RemoveProjectile()
        {
            Projectile = null;
        }

public bool ShouldShootFireball()
{
    if (projectileFired)
        return false;

    if (Projectile != null)
        return false;

    if (!PlayingAction)
        return false;

    if (MovingLeft || MovingRight)
        return false;

    if (ActionStrength != 30)
        return false;

    if (AnimationFrame < EndFrame)
        return false;

    projectileFired = true;

    return true;
}


        // ==============================
        // RESET
        // ==============================

public override void Reset()
{
    PlayingAction = false;
    ActionStrength = 0;
    projectileFired = false;

    if (CrouchedDown)
    {
        ChangeAnimation(Crouched);
        return;
    }

    CurrentImage = Standing;
    SetUpAnimation();
}
    }
}